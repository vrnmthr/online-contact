import React, { Component } from 'react';
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';


class CustomForm extends Component {

  constructor(props){
      super(props)
      this.state = {
          name: this.props.name,
          handleChange: this.props.handleChange
      }
  }

  render() {
    return (
        <Form onSubmit = {this.state.handleChange()}>
        <Form.Group controlId="name">
            <Form.Label>Name</Form.Label>
            <Form.Control type="text" placeholder="Enter name" value = {this.state.name} onChange = {(e) => this.setState({name: e.target.value})}/>
            <Form.Text className="text-muted">
            PSSS change it up to baffle everyone else heehee
            </Form.Text>
        </Form.Group>
        <Button variant="primary" type="submit">
            Submit
        </Button>
    </Form>
    )
  }
}

export default CustomForm;